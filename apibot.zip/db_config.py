## DB config. Put in .gitignore
db_host = 'labor.c5faqozfo86k.us-west-2.rds.amazonaws.com'
db_username = 'laboruser'
db_password = 'laborpass'
db_name = 'labor'
