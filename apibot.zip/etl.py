import luigi 

class CreateSkillTable(luigi.Task):
    pass
